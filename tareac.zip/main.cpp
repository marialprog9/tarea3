/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
int main(){
    
    int num1, num2, resultado;
    char op;
    
    cout << "Digite un numero: " <<endl;
    cin >> num1;
    
    cout << "Seleccione una operacion [+,-,/,*]" <<endl;
    cin>> op;
    
    cout << "Digite un segundo numero: " <<endl;
    cin >> num2;
    
    if(op=='+')
    resultado = num1 + num2;
    else if(op=='-')
    resultado = num1 - num2;
    else if(op=='*')
    resultado = num1 * num2;
    else if(op=='/')
    resultado = num1 / num2;
    
    cout <<num1<< op << num2<< "=" << resultado <<endl;
    
    
    return 0;
}
